import playsound as ps
import sounddevice as sd
from scipy.io.wavfile import write
import wave
def hearsnd:
    fs = 44100  # Sample rate
    seconds = 3  # Duration of recording
    myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=2)
    sd.wait()  # Wait until recording is finished
    write('output.wav', fs, myrecording)  # Save as WAV file
    w_one=wave.open('output.wav')
    s1=wave.open('shortsoundA.wav')
    s2=wave.open('shortsoundB.wav')
    s3=wave.open('shortsoundC.wav')
    s4=wave.open('beep-04.wav')
    s5=wave.open('beep-05.wav')
    s6=wave.open('beep-06.wav')
    s7=wave.open('beep-07.wav')
    s8=wave.open('beep-08.wav')
    s9=wave.open('beep-09.wav')
    s10=wave.open('beep-10.wav')
    s11=wave.open('beep-11.wav')
    s12=wave.open('beep-12.wav')
    s13=wave.open('beep-13.wav')
    s14=wave.open('beep-14.wav')
    s15=wave.open('beep-15.wav')
    s16=wave.open('beep-16.wav')
    s17=wave.open('beep-17.wav')
    s18=wave.open('beep-18.wav')
    s19=wave.open('beep-19.wav')
    s20=wave.open('beep-20.wav')
    s21=wave.open('beep-21.wav')
    s22=wave.open('beep-22.wav')
    s23=wave.open('beep-23.wav')
    s24=wave.open('beep-24.wav')
    s25=wave.open('beep-25.wav')
    s26=wave.open('beep-26.wav')
    if w_one.readframes() == s1.readframes():
        print('Sound A Detected')
    if w_one.readframes() == s2.readframes():
        print('Sound B Detected') 
    if w_one.readframes() == s3.readframes():
        print('Sound C Detected')  
    if w_one.readframes() == s4.readframes():
        print('Sound D Detected')  
    if w_one.readframes() == s5.readframes():
        print('Sound E Detected')  
    if w_one.readframes() == s6.readframes():
        print('Sound F Detected')
    if w_one.readframes() == s7.readframes():
        print('Sound G Detected') 
    if w_one.readframes() == s8.readframes():
        print('Sound H Detected')  
    if w_one.readframes() == s9.readframes(): 
        print('Sound I Detected') 
    if w_one.readframes() == s10.readframes(): 
        print('Sound J Detected')
    if w_one.readframes() == s11.readframes(): 
        print('Sound K Detected')
    if w_one.readframes() == s12.readframes(): 
        print('Sound L Detected')
    if w_one.readframes() == s13.readframes():
        print('Sound M Detected')
    if w_one.readframes() == s14.readframes():
        print('Sound N Detected')
    if w_one.readframes() == s15.readframes():
        print('Sound O Detected')
    if w_one.readframes() == s16.readframes():
        print('Sound P Detected')
    if w_one.readframes() == s17.readframes():
        print('Sound Q Detected')
    if w_one.readframes() == s18.readframes():
        print('Sound R Detected')
    if w_one.readframes() == s19.readframes():
        print('Sound S Detected')
    if w_one.readframes() == s20.readframes():
        print('Sound T Detected')
    if w_one.readframes() == s21.readframes():
        print('Sound U Detected')
    if w_one.readframes() == s22.readframes():
        print('Sound V Detected')
    if w_one.readframes() == s23.readframes():
        print('Sound W Detected')
    if w_one.readframes() == s24.readframes():
        print('Sound X Detected')
    if w_one.readframes() == s25.readframes():
        print('Sound Y Detected')
    if w_one.readframes() == s26.readframes():
        print('Sound Z Detected')
    else:
        print('Sound not recognized')
        hearsnd()
def playsnd:
    ltp=input('Letter to play: ')
    if ltp='A':
        ps('shortsoundA.wav')
    if ltp='B':
        ps('shortsoundB.wav')
    if ltp='C':
        ps('shortsoundC.wav')
    if ltp='D':
        ps('beep-04.wav')
    if ltp='E':
        ps('beep-05.wav')
    if ltp='F':
        ps('beep-06.wav')
    if ltp='G':
        ps('beep-07.wav')
    if ltp='H':
        ps('beep-08.wav')
    if ltp='I':
        ps('beep-09.wav')
    if ltp='J':
        ps('beep-10.wav')
    if ltp='K':
        ps('beep-11.wav')
    if ltp='L':
        ps('beep-12.wav')
    if ltp='M':
        ps('beep-13.wav')
    if ltp='N':
        ps('beep-14.wav')
    if ltp='O:
        ps('beep-15.wav')
    if ltp='P':
        ps('beep-16.wav')
    if ltp='Q':
        ps('beep-17.wav')
    if ltp='R':
        ps('beep-18.wav')
    if ltp='S':
        ps('beep-19.wav')
    if ltp='T':
        ps('beep-20.wav')
    if ltp='U':
        ps('beep-21.wav')
    if ltp='V':
        ps('beep-22.wav')
    if ltp='W':
        ps('beep-23.wav')
    if ltp='X':
        ps('beep-24.wav')
    if ltp='Y':
        ps('beep-25.wav')
    if ltp='Z':
        ps('beep-26.wav')
thingtodo=input('Hear or Send')
if thingtodo=='Hear':
    hearsnd()
if thingtodo=='Send':
    playsnd()